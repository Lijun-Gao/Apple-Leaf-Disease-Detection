# import xml.etree.ElementTree as ET
# import os, cv2
# import numpy as np
# from os import listdir
# from os.path import join
#
# classes = []
#
# def convert(size, box):
#     dw = 1. / (size[0])
#     dh = 1. / (size[1])
#     x = (box[0] + box[1]) / 2.0 - 1
#     y = (box[2] + box[3]) / 2.0 - 1
#     w = box[1] - box[0]
#     h = box[3] - box[2]
#     x = x * dw
#     w = w * dw
#     y = y * dh
#     h = h * dh
#     return (x, y, w, h)
#
#
# def convert_annotation(xmlpath, xmlname):
#     with open(xmlpath, "r", encoding='utf-8') as in_file:
#         txtname = xmlname[:-4] + '.txt'
#         txtfile = os.path.join(txtpath, txtname)
#         tree = ET.parse(in_file)
#         root = tree.getroot()
#         filename = root.find('filename')
#         img = cv2.imdecode(np.fromfile('{}/{}.{}'.format(imgpath, xmlname[:-4], postfix), np.uint8), cv2.IMREAD_COLOR)
#         h, w = img.shape[:2]
#         res = []
#         for obj in root.iter('object'):
#             cls = obj.find('name').text
#             if cls not in classes:
#                 classes.append(cls)
#             cls_id = classes.index(cls)
#             xmlbox = obj.find('bndbox')
#             b = (float(xmlbox.find('xmin').text), float(xmlbox.find('xmax').text), float(xmlbox.find('ymin').text),
#                  float(xmlbox.find('ymax').text))
#             bb = convert((w, h), b)
#             res.append(str(cls_id) + " " + " ".join([str(a) for a in bb]))
#         if len(res) != 0:
#             with open(txtfile, 'w+') as f:
#                 f.write('\n'.join(res))
#
#
# if __name__ == "__main__":
#     postfix = 'jpg'
#     imgpath = 'VOCdevkit/JPEGImages'
#     xmlpath = 'VOCdevkit/Annotations'
#     txtpath = 'VOCdevkit/txt'
#
#     if not os.path.exists(txtpath):
#         os.makedirs(txtpath, exist_ok=True)
#
#     list = os.listdir(xmlpath)
#     error_file_list = []
#     for i in range(0, len(list)):
#         try:
#             path = os.path.join(xmlpath, list[i])
#             if ('.xml' in path) or ('.XML' in path):
#                 convert_annotation(path, list[i])
#                 print(f'file {list[i]} convert success.')
#             else:
#                 print(f'file {list[i]} is not xml format.')
#         except Exception as e:
#             print(f'file {list[i]} convert error.')
#             print(f'error message:\n{e}')
#             error_file_list.append(list[i])
#     print(f'this file convert failure\n{error_file_list}')
#     print(f'Dataset Classes:{classes}')

import cv2
import os
import xml.etree.ElementTree as ET

def yolo_to_voc(yolo_folder, voc_folder, img_folder):
    # 创建保存VOC标注的文件夹
    if not os.path.exists(voc_folder):
        os.makedirs(voc_folder)

    # 遍历YOLO格式标注文件
    for yolo_file in os.listdir(yolo_folder):
        if yolo_file.endswith(".txt"):
            yolo_filepath = os.path.join(yolo_folder, yolo_file)
            img_filename = os.path.splitext(yolo_file)[0] + ".jpg"
            img_filepath = os.path.join(img_folder, img_filename)

            # 检查文件是否存在
            if not os.path.exists(img_filepath):
                print(f"Error: Image file {img_filepath} does not exist.")
                continue

            # 读取图片，获取图片宽度和高度
            img = cv2.imread(img_filepath)
            if img is None:
                print(f"Error: Unable to load image at {img_filepath}")
                continue

            height, width, _ = img.shape

            # 创建VOC格式的xml文件
            voc_file = os.path.join(voc_folder, os.path.splitext(yolo_file)[0] + ".xml")
            annotation = ET.Element("annotation")
            ET.SubElement(annotation, "folder").text = "VOC2012"
            ET.SubElement(annotation, "filename").text = img_filename
            ET.SubElement(annotation, "path").text = img_filepath

            source = ET.SubElement(annotation, "source")
            ET.SubElement(source, "database").text = "Unknown"

            size = ET.SubElement(annotation, "size")
            ET.SubElement(size, "width").text = str(width)
            ET.SubElement(size, "height").text = str(height)
            ET.SubElement(size, "depth").text = "3"

            ET.SubElement(annotation, "segmented").text = "0"

            with open(yolo_filepath, "r") as file:
                for line in file:
                    parts = line.strip().split()
                    class_id = int(parts[0])
                    x_center, y_center, w, h = map(float, parts[1:])

                    xmin = int((x_center - w / 2) * width)
                    ymin = int((y_center - h / 2) * height)
                    xmax = int((x_center + w / 2) * width)
                    ymax = int((y_center + h / 2) * height)

                    obj = ET.SubElement(annotation, "object")
                    ET.SubElement(obj, "name").text = str(class_id)  # 根据需要替换为类别名称
                    ET.SubElement(obj, "pose").text = "Unspecified"
                    ET.SubElement(obj, "truncated").text = "0"
                    ET.SubElement(obj, "difficult").text = "0"

                    bndbox = ET.SubElement(obj, "bndbox")
                    ET.SubElement(bndbox, "xmin").text = str(xmin)
                    ET.SubElement(bndbox, "ymin").text = str(ymin)
                    ET.SubElement(bndbox, "xmax").text = str(xmax)
                    ET.SubElement(bndbox, "ymax").text = str(ymax)

            tree = ET.ElementTree(annotation)
            tree.write(voc_file)

if __name__ == "__main__":
    yolo_folder = 'E:/yolov8/Data/datasets/txt'  # YOLO标签文件夹路径
    voc_folder = 'C:/Users/LIjun Gao/Desktop/苹果病害检测/Data/VOC'  # 保存VOC标签的文件夹路径
    img_folder = 'E:/yolov8/Data/datasets/images'  # 图像文件夹路径

    yolo_to_voc(yolo_folder, voc_folder, img_folder)
