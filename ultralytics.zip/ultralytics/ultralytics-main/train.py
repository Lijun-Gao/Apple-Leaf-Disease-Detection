import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO
import torch

torch.cuda.empty_cache()
import os
os.environ['ALBUMENTATIONS_SKIP_VERSION_CHECK'] = '1'
import wandb
wandb.init(mode='disabled')  # 禁用 WandB




# 训练参数官方详解链接：https://docs.ultralytics.com/modes/train/#resuming-interrupted-trainings:~:text=a%20training%20run.-,Train%20Settings,-The%20training%20settings

if __name__ == '__main__':
    model = YOLO('ultralytics/cfg/models/v3/yolov3-tiny.yaml')
    # model = YOLO('ultralytics-main/runs/train/exp12/weights/last.pt')
    # model.load('yolov8s.pt') # loading pretrain weights
    model.train(data='dataset/data.yaml',
                cache=False,
                imgsz=640,
                epochs=300,
                batch=16,
                close_mosaic=0,
                workers=4,
                # device='0',
                optimizer='SGD', # using SGD
                # patience=0, # close earlystop
                # resume=True, # 断点续训,YOLO初始化时选择last.pt
                # amp=False, # close amp
                # fraction=0.2,
                project='runs/train',
                name='exp',
                )