# import torch
# from torchvision import transforms
# from torch.utils.data import DataLoader
#
# # 加载YOLOv8模型，使用提供的权重路径
# model = torch.load('E:/yolov8/ultralytics-20240713/ultralytics-main/runs/train/YOLOv10m/weights/best.pt')
# model.eval()  # 设置模型为评估模式
#
# # 数据预处理
# transform = transforms.Compose([
#     transforms.Resize((640, 640)),  # 根据YOLOv8输入大小进行调整
#     transforms.ToTensor(),
# ])
#
# # 加载测试数据集（这里使用自定义数据集作为示例）
# # 请确保你自己的数据集有合适的格式
# dataset = YourCustomDataset(root='E:/yolov8/Data/0.5Appleleavesoriginaldata/test/images', transform=transform)
# data_loader = DataLoader(dataset, batch_size=4, shuffle=False)
#
# # 标签类别
# class_names = ['Alternarialeafspot', 'Brownspot', 'Frogeyeleafspot', 'Mosaic',
#                'Powderymildew', 'Rust', 'Scab', 'Health']
# num_classes = len(class_names)
#
# # 计算准确率
# correct_predictions = 0
# total_predictions = 0
#
# with torch.no_grad():
#     for images, targets in data_loader:
#         # 获取模型预测
#         predictions = model(images)
#
#         # 在这里，你需要根据你的数据集格式和模型输出格式来处理预测
#         for i in range(len(predictions)):
#             pred_labels = predictions[i]['labels'].cpu().numpy()  # 获取预测标签
#             pred_scores = predictions[i]['scores'].cpu().numpy()  # 获取预测分数
#             true_labels = targets[i]['annotation']['object']  # 获取真实标签
#
#             # 将真实标签转换为类别索引
#             true_label_indices = [class_names.index(true['name']) for true in true_labels]
#
#             # 统计正确的预测
#             for pred_label, score in zip(pred_labels, pred_scores):
#                 if pred_label in true_label_indices and score > 0.5:  # 设置阈值
#                     correct_predictions += 1
#
#             total_predictions += len(true_label_indices)  # 更新总的标签数
#
# # 计算准确率
# accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0
# print(f'Accuracy: {accuracy:.4f}')

import albumentations as A
A.__version__ = "0.0.0"  # 禁用版本检查
import os
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from ultralytics import YOLO
import wandb

# Disable WandB if you don't want to use it
wandb.init(mode='disabled')


class YourCustomDataset(Dataset):
    def __init__(self, root, transform=None):
        self.root = root
        self.transform = transform
        self.images = [f for f in os.listdir(root) if f.endswith(('.jpg', '.png'))]

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_name = os.path.join(self.root, self.images[idx])
        image = Image.open(img_name).convert('RGB')

        if self.transform:
            image = self.transform(image)

        # 假设每张图像对应一个标签文件
        label_name = img_name.replace('images', 'labels').replace('.jpg', '.txt').replace('.png', '.txt')
        with open(label_name, 'r') as f:
            labels = f.readlines()

        # 处理标签
        targets = [{'name': line.split()[0], 'bbox': [float(x) for x in line.split()[1:]]} for line in labels]

        return image, targets


# 数据预处理
transform = transforms.Compose([
    transforms.Resize((640, 640)),
    transforms.ToTensor(),
])

# 加载测试数据集
dataset = YourCustomDataset(root='E:/yolov8/Data/0.5Appleleavesoriginaldata/test/images', transform=transform)
data_loader = DataLoader(dataset, batch_size=1, shuffle=False)

# 标签类别
class_names = ['Alternarialeafspot', 'Brownspot', 'Frogeyeleafspot', 'Mosaic',
               'Powderymildew', 'Rust', 'Scab', 'Health']
num_classes = len(class_names)


# 计算准确率
def evaluate_model():
    model = YOLO('E:/yolov8/ultralytics-20240713/ultralytics-main/runs/train/YOLOv10m/weights/best.pt')
    model.eval()  # 设置模型为评估模式

    correct_predictions = 0
    total_predictions = 0

    with torch.no_grad():
        for images, targets in data_loader:
            # 获取模型预测
            predictions = model(images)

            for i in range(len(predictions)):
                pred_labels = predictions[i]['labels'].cpu().numpy()  # 获取预测标签
                pred_scores = predictions[i]['scores'].cpu().numpy()  # 获取预测分数
                true_labels = targets[i]  # 获取真实标签

                # 将真实标签转换为类别索引
                true_label_indices = [class_names.index(true['name']) for true in true_labels]

                # 统计正确的预测
                for pred_label, score in zip(pred_labels, pred_scores):
                    if pred_label in true_label_indices and score > 0.5:  # 设置阈值
                        correct_predictions += 1

                total_predictions += len(true_label_indices)

    # 计算准确率
    accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0
    print(f'Accuracy: {accuracy:.4f}')


if __name__ == '__main__':
    import torch.multiprocessing as mp

    mp.set_start_method('spawn', force=True)

    evaluate_model()
